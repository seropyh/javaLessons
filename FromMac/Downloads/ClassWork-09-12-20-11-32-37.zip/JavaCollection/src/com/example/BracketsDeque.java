package com.example;

import java.util.ArrayDeque;

public class BracketsDeque {
	
	public static void main(String[] args) {
		var deque = new ArrayDeque<Character>();
	}

}
