module JavaCollection {
}