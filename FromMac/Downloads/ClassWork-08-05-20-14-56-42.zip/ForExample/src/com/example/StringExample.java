package com.example;

import java.util.Scanner;

public class StringExample {

	public static void main(String[] args) {
		var a = new String("a");
		var b = new String("a");
		
		var c = "Привет";
		var d = "приВеТ";
		
		var scanner = new Scanner(System.in);
		String line = null;
		System.out.println(line.equals("привет"));
//		System.out.println("привет".equals(line));
		
//		System.out.println(a == b);
//		System.out.println(c.equalsIgnoreCase(d));

	}

}
