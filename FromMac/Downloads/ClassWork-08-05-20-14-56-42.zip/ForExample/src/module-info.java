module ForExample {
}