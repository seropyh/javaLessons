package com.example.lesson22.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class FormBlog {

    private String title;
    private String content;
}
