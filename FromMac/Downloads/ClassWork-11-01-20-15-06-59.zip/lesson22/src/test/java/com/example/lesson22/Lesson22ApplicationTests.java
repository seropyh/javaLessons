package com.example.lesson22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lesson22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
