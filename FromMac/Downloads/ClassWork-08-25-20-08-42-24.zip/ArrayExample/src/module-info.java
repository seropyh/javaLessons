module ArrayExample {
}