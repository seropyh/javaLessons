package com.example.newsagregate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsagregateApplicationTests {

	@Test
	void contextLoads() {
	}

}
