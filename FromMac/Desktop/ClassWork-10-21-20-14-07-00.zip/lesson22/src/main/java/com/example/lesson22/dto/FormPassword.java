package com.example.lesson22.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class FormPassword {

    private String login;
    private String password;
}
