package com.example.lesson21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson21Application {

	public static void main(String[] args) {
		SpringApplication.run(Lesson21Application.class, args);
	}

}
