package com.example.newsagregate.config;

public class SpringSecurityDialect {
}
