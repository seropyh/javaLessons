package com.example.newsagregate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsagregateApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsagregateApplication.class, args);
	}

}
